# 04 - Update Blog Layout

---

## Tasks

- Create an **"index.html"** file with title - **"Update Blog Layout"**
- Copy the latest code from Blog layout with flexbox
- Copy your **multilevel dropdown**
- Make the menu **responsive**
- Get the latest typography css
- Move the layout code to layout.css
- Move the navigation code to navigation.css
- Create **reset.css** file
- Include all CSS files from the main styles.css file
