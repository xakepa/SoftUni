# 08 - Responsive tables

---

## Tasks

- Create an **"index.html"** file with title - **Responsive tables**
- Create a table with 3 columns, First Name, Last Name, Job Title
- Get the latest reset.css
- Get the latest typography.css
- Make the table responsive
