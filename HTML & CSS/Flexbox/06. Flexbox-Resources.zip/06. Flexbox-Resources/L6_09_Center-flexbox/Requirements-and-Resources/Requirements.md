# 09 - Center Flexbox
------
Problems for in-class lab for the [“HTML & CSS”](https://softuni.bg/trainings/2784/html-and-css-february-2020) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1236/Flexbox).

## Tasks
 * Create an **"index.html"** file with title - **"Center Flexbox"**

## Constraints
 * The document **background** color has to be **rgb(238, 238, 238)**
 * The body **display** propery has to be **flex**
 * The **content** must be placed into **div** with **class card** *(div.card)*
    * The div **background** color has to be **rgb(255, 255, 255)**
